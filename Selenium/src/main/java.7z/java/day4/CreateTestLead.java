
package day4;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import wrappers.GenericWrappers;
import wrappers.LeafTaps_Wrappers;
public class CreateTestLead extends LeafTaps_Wrappers{
	//@Test(invocationCount=2,invocationTimeOut=30000)
	@Test
	public void createTestLead() throws Exception{
		
		/*invokeApp("chrome", "http://leaftaps.com");
		enterById("username", "DemoSalesManager");
		enterById("password", "crmsfa");
		clickByClassName("decorativeSubmit");*/
		clickByLink("CRM/SFA");
		clickByLink("Create Lead");
		enterById("createLeadForm_companyName","Yesh Solutions");
		enterById("createLeadForm_firstName","Yeshvanth");
		enterById("createLeadForm_lastName","kannan");
		selectVisibileTextById("createLeadForm_dataSourceId","Conference");
		selectIndexById("createLeadForm_marketingCampaignId",3);
		enterById("createLeadForm_firstNameLocal","Yesh");
		enterById("createLeadForm_lastNameLocal","K");
		enterById("createLeadForm_personalTitle","MR");
		enterById("createLeadForm_generalProfTitle","K.Y");
		enterById("createLeadForm_departmentName","Digital Marketing");
		enterById("createLeadForm_annualRevenue","360000");
		selectIndexByContainsTextById("createLeadForm_currencyUomId","India");
		selectIndexById("createLeadForm_industryEnumId",7);
		enterById("createLeadForm_numberEmployees","100");
		selectVisibileTextById("createLeadForm_ownershipEnumId","Sole Proprietorship");
		enterById("createLeadForm_sicCode", "67880");
		enterById("createLeadForm_importantNote", "This lead is expertise in HTML5,CSSS,JAva");
		enterById("createLeadForm_primaryPhoneCountryCode", "91");
		enterById("createLeadForm_primaryPhoneAreaCode", "44");
		enterById("createLeadForm_primaryPhoneNumber", "7200502256");
		enterById("createLeadForm_primaryEmail", "yeshchennai@gmail.com");
		enterById("createLeadForm_generalToName", "yeshvanth");
		enterById("createLeadForm_generalAddress1", "8/218 Thirumalai Nagar Pozhichlur Chennai-74");
		selectTextByValue("createLeadForm_generalCountryGeoId", "IND");
		selectTextByValue("createLeadForm_generalStateProvinceGeoId", "IN-TN");
		enterById("createLeadForm_generalPostalCode", "600074");
		clickByName("submitButton");
		closeBrowser();
	}
	@BeforeMethod
	void beforeMethod()
	{
		System.out.println("before method-create lead");
		
	}
	@AfterMethod
	void afterMthod()
	{
		System.out.println("after method-create lead");
		
	}

}
