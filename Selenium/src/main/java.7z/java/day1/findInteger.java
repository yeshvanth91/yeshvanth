package day1;

public class findInteger {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double wNum=18.98;
		int number=(int)wNum;
		double decimal=wNum-number;
				System.out.println(decimal);
	}

}
