package wrappers;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

public class LeafTaps_Wrappers extends GenericWrappers 
{
	@BeforeMethod
	public void login_Taps()
	{
		invokeApp("chrome","http://leaftaps.com/control/main");
		enterById("username","DemoSalesManager");
		enterById("password","crmsfa");
		clickByClassName("decorativeSubmit");
	}
	@AfterMethod
	public void CloseBrowser()
	{
		closeAllBrowsers();
	}
	
}
